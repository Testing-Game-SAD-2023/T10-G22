#!/bin/sh

HOST_IP=""

# Verifica se il comando 'ip' è disponibile
if command -v ip &> /dev/null; then
    # Utilizza 'ip' per ottenere l'indirizzo IP dell'host
    HOST_IP=$(ip route get 1 | awk '{print $7}')
else
    # Altrimenti, usa 'ifconfig' per ottenere l'indirizzo IP
    HOST_IP=$(ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1')
fi

# Verifica se è stato ottenuto un indirizzo IP
if [ -n "$HOST_IP" ]; then
    echo "Indirizzo IP dell'host: $HOST_IP"
    sed -i.bak -E 's/HOST_IP: ([^ ]*)/HOST_IP: '"$HOST_IP"'/g' docker-compose.yml

    echo "Sostituzione completata. HOST_VAL è stato sostituito con l'indirizzo IP: $HOST_IP"

    docker-compose up -d
else
    echo "Nessun indirizzo IP dell'host trovato."
fi